<p>
  [ <a class="ajax-nav" href="first_page.php">First example</a>
  | <a class="ajax-nav" href="second_page.php">Second example</a>
  | <a class="ajax-nav" href="third_page.php">Third example</a>
  | <a class="ajax-nav" href="unexisting.php">Unexisting page</a> ]
</p>

<p>This is the footer. It is shared between all ajax pages.</p>
